/*
 * test_menu.h
 *
 *  Created on: 4 déc. 2012
 *      Author: Evangelina Lolivier-Exler
 */

#ifndef TEST_MENU_H_
#define TEST_MENU_H_

extern int test_menu(void);

#endif /* TEST_MENU_H_ */
